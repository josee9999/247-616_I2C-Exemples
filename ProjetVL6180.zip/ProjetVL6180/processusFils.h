#ifndef PROCESSUSFILS_H
#define PROCESSUSFILS_H

//MODULE: processusFils
//DESCRIPTION: solution lab 7 partie 1

//HISTORIQUE:
// 2022-11-04, Yves Roy, creation

//DEFINITIONS REQUISES PAR LE MODULE:
//Dependances materielles
//(copiez et adaptez ce qui suit dans "main.h")
//pas de dependances materielles

//Dependances logicielles
//(copiez et adaptez ce qui suit dans "main.h")
//pas de dependances logicielles

//INFORMATION PUBLIQUE:
//Definitions publiques:
//pas de definitions publiques

//Fonctions publiques:
int processusFils_gere(void);
int processusFils_initialise(void);

//Variables publiques:
//pas de variables publiques

#endif
