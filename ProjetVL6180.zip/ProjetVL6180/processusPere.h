#ifndef PROCESSUSPERE_H
#define PROCESSUSPERE_H

//MODULE: processusPere

//HISTORIQUE:
// 2022-11-04, Yves Roy, creation

//DEFINITIONS REQUISES PAR LE MODULE:
//dependances materielles
//(copiez et adaptez ce qui suit dans "main.h")
//pas de dependances materielles

//dependances logicielles
//(copiez et adaptez ce qui suit dans "main.h")
//pas de dependances logicielles

//INFORMATION PUBLIQUE:
//definitions publiques:
//pas de definitions publiques

//declarations de fonctions publiques:
int processusPere_gere(void);
int processusPere_initialise(void);

//declarations de variables publiques:
//pas de variables publiques

#endif
